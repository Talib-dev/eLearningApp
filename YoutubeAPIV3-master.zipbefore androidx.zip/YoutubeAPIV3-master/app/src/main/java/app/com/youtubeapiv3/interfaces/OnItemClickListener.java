package app.com.youtubeapiv3.interfaces;


import app.com.youtubeapiv3.models.YoutubeDataModel;

/**
 * Created by mdmunirhossain on 12/19/17.
 */

public interface OnItemClickListener {
    void onItemClick(YoutubeDataModel item);

}
